package java.entities

interface Greetings {
}