package java.entities

class users {
}